package com.example.satramprudhvi.finalproject_madt3125.Adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

public class PlacesRankingAdapter extends RecyclerView.Adapter<RankedPlacesAdapter.ViewHolder> {
    @NonNull
    @Override
    public RankedPlacesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RankedPlacesAdapter.ViewHolder viewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
