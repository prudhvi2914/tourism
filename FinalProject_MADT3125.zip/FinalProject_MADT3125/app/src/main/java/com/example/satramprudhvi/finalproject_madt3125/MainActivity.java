package com.example.satramprudhvi.finalproject_madt3125;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.satramprudhvi.finalproject_madt3125.models.LocaleUtils;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
        Button btnLogin, btnRegister;
        EditText edtEmail, edtPassword;
        DBHelper dbHelper;
        SQLiteDatabase TourBuddyDB;
        Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.context = this;

     btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

       btnRegister = findViewById(R.id.btnRegister);
       btnRegister.setOnClickListener(this);

       edtEmail = findViewById(R.id.edtEmail);
       edtPassword = findViewById(R.id.edtPassword);

       dbHelper = new DBHelper(this);
        //translation onCreate
        SharedPreferences preferences = getSharedPreferences("com.example.joorebelo.finalproject.shared", Context.MODE_PRIVATE);
       String lang = preferences.getString("LANG", "");
        boolean langSelected = preferences.getBoolean("langSelected", false);
        SharedPreferences.Editor editor = preferences.edit();
        if (langSelected) {
            editor.clear();
            editor.putString("LANG", lang);
           editor.putBoolean("langSelected", true);
           editor.apply();
            LocaleUtils.updateConfig(this,lang);
        } else {
            LocaleUtils.updateConfig(this, Locale.getDefault().getLanguage());
            editor.clear();
           editor.putString("lang", Locale.getDefault().getLanguage());
            editor.putBoolean("langSelected", false);
            editor.apply();

       }

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnLogin.getId()){
            String username = edtEmail.getText().toString();
            String password = edtPassword.getText().toString();
            if (verifyLogin()){
                finish();
                Toast.makeText(this, "LoginSucessfull", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this,NaigationDrawerHome.class));
            }else{
                Toast.makeText(this,"Invalid Email/Password", Toast.LENGTH_SHORT).show();
            }
        }else if(view.getId() == btnRegister.getId()){
            Intent RegistrationActivity = new Intent(MainActivity.this, RegistrationActivity.class);

           startActivity(RegistrationActivity);

        }
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent RegistrationActivity = new Intent(MainActivity.this, RegistrationActivity.class);

                startActivity(RegistrationActivity);

            }
        });

    }
    private boolean verifyLogin() {
        try {

            TourBuddyDB = dbHelper.getReadableDatabase();
            String columns[] = {"email", "password"};
            String userData[] = {edtEmail.getText().toString(), edtPassword.getText().toString()};

            Cursor cursor = TourBuddyDB.query("User", columns, "email = ? AND password = ?", userData,null, null,null);
            if(cursor != null){
                if(cursor.getCount() > 0){
                    //save to SharedPreferences
                    SharedPreferences sp = getSharedPreferences("com.example.joorebelo.finalproject.shared", Context.MODE_PRIVATE);
                    SharedPreferences.Editor edit = sp.edit();
                    edit.putString("UserEmail", edtEmail.getText().toString());
                   edit.commit();

                    return true;
               }
            }
            return false;


        }catch (Exception e){
            Log.e("LoginActivity", e.getMessage());
            return false;
        }finally {
            TourBuddyDB.close();
       }
    }

    }

